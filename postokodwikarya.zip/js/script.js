document.addEventListener('DOMContentLoaded', function() {
  console.log('Project postokodwikarya is ready!');
});